define("epi-cms/contentediting/command/LanguageSelection", [
    "dojo/_base/declare",
    "dojo/_base/lang",
    // Parent class
    "epi/shell/command/OptionCommand",

    // Resources
    "epi/i18n!epi/cms/nls/episerver.cms.contentediting"
], function (
    declare,
    lang,
    // Parent class
    OptionCommand,

    // Resources
    resources
) {

    return declare([OptionCommand], {
        // summary:
        //      A command for selecting the current compare view
        
        optionsLabel: resources.contentdetails.existinglanguages,

        active: false,

        _selectedSetter: function(selected) {
            // summary:
            //      Overridden to set label based on the currently selected option
            this.inherited(arguments);

            if(typeof(selected) ==  "string" && selected !== "") {
                this.set("label", selected.toUpperCase() );
                if(selected != this.model.get("documentLanguage")) {
                    this.set("active", true);
                } else {
                    this.set("active", false);
                }
            }

        }

    });
});
